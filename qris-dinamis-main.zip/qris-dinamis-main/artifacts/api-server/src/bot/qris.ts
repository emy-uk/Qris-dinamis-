import axios from "axios";

export interface QrisData {
  merchantName: string;
  merchantCity: string;
  merchantCategoryCode: string;
  transactionCurrency: string;
  countryCode: string;
  rawString: string;
  isValid: boolean;
  errorMessage?: string;
}

interface TlvEntry {
  tag: string;
  length: number;
  value: string;
}

/**
 * Parse EMV TLV string into an array of tag-length-value entries.
 * Walks strictly by length field — never by substring search.
 */
function parseTlv(data: string): TlvEntry[] {
  const entries: TlvEntry[] = [];
  let pos = 0;

  while (pos + 4 <= data.length) {
    const tag = data.substring(pos, pos + 2);
    const lenStr = data.substring(pos + 2, pos + 4);
    const len = parseInt(lenStr, 10);

    if (isNaN(len) || pos + 4 + len > data.length) break;

    const value = data.substring(pos + 4, pos + 4 + len);
    entries.push({ tag, length: len, value });
    pos += 4 + len;
  }

  return entries;
}

/**
 * Serialise TLV entries back to string.
 */
function serializeTlv(entries: TlvEntry[]): string {
  return entries
    .map((e) => `${e.tag}${String(e.length).padStart(2, "0")}${e.value}`)
    .join("");
}

/**
 * CRC16-CCITT (0x1021) used by EMV QRCPS.
 * Initial value 0xFFFF, computed over the full payload including "6304".
 */
function crc16Ccitt(data: string): number {
  let crc = 0xffff;
  for (let i = 0; i < data.length; i++) {
    crc ^= data.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      crc = crc & 0x8000 ? ((crc << 1) ^ 0x1021) & 0xffff : (crc << 1) & 0xffff;
    }
  }
  return crc;
}

function appendCrc(payload: string): string {
  const withTag = payload + "6304";
  const crc = crc16Ccitt(withTag);
  return withTag + crc.toString(16).toUpperCase().padStart(4, "0");
}

// ---------------------------------------------------------------------------

/**
 * Decode QR code image URL to string using goqr.me API
 */
export async function decodeQrisFromUrl(imageUrl: string): Promise<string> {
  const apiUrl = `https://api.qrserver.com/v1/read-qr-code/?fileurl=${encodeURIComponent(imageUrl)}`;
  const response = await axios.get(apiUrl, { timeout: 15000 });
  const data = response.data;
  if (Array.isArray(data) && data[0]?.symbol?.[0]?.data) {
    return data[0].symbol[0].data as string;
  }
  throw new Error("Tidak bisa membaca QR code dari gambar.");
}

/**
 * Decode QR code from binary buffer using goqr.me API
 */
export async function decodeQrisFromBuffer(buffer: Buffer, filename = "qris.jpg"): Promise<string> {
  const FormData = (await import("form-data")).default;
  const form = new FormData();
  form.append("file", buffer, { filename, contentType: "image/jpeg" });

  const response = await axios.post("https://api.qrserver.com/v1/read-qr-code/", form, {
    headers: form.getHeaders(),
    timeout: 15000,
  });

  const data = response.data;
  if (Array.isArray(data) && data[0]?.symbol?.[0]?.data) {
    const result = data[0].symbol[0].data as string;
    if (!result || result === "null") {
      throw new Error("QR code tidak terbaca. Pastikan gambar QRIS jelas dan tidak buram.");
    }
    return result;
  }
  throw new Error("Format respons API tidak valid.");
}

/**
 * Parse EMV QRIS string into structured data
 */
export function parseQrisString(qrisString: string): QrisData {
  const empty: QrisData = {
    merchantName: "",
    merchantCity: "",
    merchantCategoryCode: "",
    transactionCurrency: "360",
    countryCode: "ID",
    rawString: qrisString,
    isValid: false,
  };

  if (!qrisString?.trim()) return { ...empty, errorMessage: "String QRIS kosong" };
  if (!qrisString.startsWith("000201")) {
    return { ...empty, errorMessage: "Bukan format QRIS yang valid (harus diawali 000201)" };
  }

  // Strip CRC from the end before parsing
  const payload = qrisString.replace(/6304[A-Fa-f0-9]{4}$/, "");
  const tags = parseTlv(payload);

  const result: QrisData = { ...empty, isValid: true };
  for (const { tag, value } of tags) {
    switch (tag) {
      case "52": result.merchantCategoryCode = value; break;
      case "53": result.transactionCurrency = value; break;
      case "58": result.countryCode = value; break;
      case "59": result.merchantName = value; break;
      case "60": result.merchantCity = value; break;
    }
  }

  if (!result.merchantName) {
    return { ...result, isValid: false, errorMessage: "Nama merchant tidak ditemukan dalam QRIS" };
  }

  return result;
}

/**
 * Convert static QRIS (tag 01 = "11") to dynamic QRIS (tag 01 = "12")
 * with a specific transaction amount (tag 54).
 *
 * Strategy: parse the full TLV structure, mutate the necessary tags,
 * rebuild the string, then recalculate CRC16-CCITT.
 */
export function generateDynamicQris(staticQrisString: string, nominalAmount: number): string {
  // Strip CRC suffix — it will be recalculated
  const payload = staticQrisString.replace(/6304[A-Fa-f0-9]{4}$/, "");
  const tags = parseTlv(payload);

  // 1. Change Point of Initiation Method from "11" (static) to "12" (dynamic)
  for (const entry of tags) {
    if (entry.tag === "01") {
      entry.value = "12";
      entry.length = 2;
      break;
    }
  }

  // 2. Remove any existing transaction amount tag (54)
  const existingAmountIdx = tags.findIndex((e) => e.tag === "54");
  if (existingAmountIdx !== -1) tags.splice(existingAmountIdx, 1);

  // 3. Insert tag 54 at the correct EMV position: after tag 53 (currency),
  //    before tag 58 (country code). If neither found, insert before tag 59.
  const amountStr = Math.round(nominalAmount).toString();
  const amountEntry: TlvEntry = { tag: "54", length: amountStr.length, value: amountStr };

  const insertBeforeTag = ["58", "59", "60"];
  let insertIdx = tags.findIndex((e) => insertBeforeTag.includes(e.tag));
  if (insertIdx === -1) insertIdx = tags.length; // fallback: append before CRC
  tags.splice(insertIdx, 0, amountEntry);

  // 4. Rebuild and sign with fresh CRC
  return appendCrc(serializeTlv(tags));
}

/**
 * Generate QR code image URL from string using goqr.me
 */
export function generateQrImageUrl(data: string, size = 300): string {
  return `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&data=${encodeURIComponent(data)}&format=png&margin=10`;
}

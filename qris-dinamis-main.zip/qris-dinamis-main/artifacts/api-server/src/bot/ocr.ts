import { createWorker } from "tesseract.js";
import axios from "axios";
import path from "path";
import os from "os";
import fs from "fs/promises";

/**
 * Perform OCR on an image buffer
 */
export async function ocrFromBuffer(imageBuffer: Buffer, lang = "ind+eng"): Promise<string> {
  const tmpFile = path.join(os.tmpdir(), `ocr_${Date.now()}.jpg`);
  await fs.writeFile(tmpFile, imageBuffer);

  try {
    const worker = await createWorker(lang, 1, {
      cachePath: path.join(os.tmpdir(), "tesseract-cache"),
      logger: () => {},
    });

    const { data: { text } } = await worker.recognize(tmpFile);
    await worker.terminate();

    const cleaned = text
      .split("\n")
      .map((line) => line.trim())
      .filter((line) => line.length > 0)
      .join("\n");

    return cleaned || "Tidak ada teks yang terdeteksi dalam gambar.";
  } finally {
    await fs.unlink(tmpFile).catch(() => {});
  }
}

/**
 * Download image from Telegram file URL and run OCR
 */
export async function ocrFromUrl(fileUrl: string): Promise<string> {
  const response = await axios.get(fileUrl, { responseType: "arraybuffer", timeout: 30000 });
  const buffer = Buffer.from(response.data as ArrayBuffer);
  return ocrFromBuffer(buffer);
}

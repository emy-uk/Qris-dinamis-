import type { InlineKeyboardMarkup } from "node-telegram-bot-api";

export const mainMenuKeyboard: InlineKeyboardMarkup = {
  inline_keyboard: [
    [{ text: "📷  OCR — Foto ke Teks", callback_data: "menu_ocr" }],
    [{ text: "🔄  QRIS Statis → Dinamis", callback_data: "menu_qris" }],
    [
      { text: "📜 Riwayat", callback_data: "menu_history" },
      { text: "ℹ️ Bantuan", callback_data: "menu_help" },
    ],
  ],
};

export const backToMenuKeyboard: InlineKeyboardMarkup = {
  inline_keyboard: [
    [{ text: "🏠 Kembali ke Menu Utama", callback_data: "menu_main" }],
  ],
};

export const cancelKeyboard: InlineKeyboardMarkup = {
  inline_keyboard: [
    [{ text: "❌ Batalkan & Kembali ke Menu", callback_data: "menu_main" }],
  ],
};

export const ocrLanguageKeyboard: InlineKeyboardMarkup = {
  inline_keyboard: [
    [
      { text: "🇮🇩 Indonesia + Inggris", callback_data: "ocr_lang_ind+eng" },
      { text: "🇬🇧 Inggris saja", callback_data: "ocr_lang_eng" },
    ],
    [{ text: "❌ Batalkan & Kembali ke Menu", callback_data: "menu_main" }],
  ],
};

export const qrisNominalKeyboard: InlineKeyboardMarkup = {
  inline_keyboard: [
    [
      { text: "Rp 5.000", callback_data: "nominal_5000" },
      { text: "Rp 10.000", callback_data: "nominal_10000" },
      { text: "Rp 20.000", callback_data: "nominal_20000" },
    ],
    [
      { text: "Rp 50.000", callback_data: "nominal_50000" },
      { text: "Rp 100.000", callback_data: "nominal_100000" },
      { text: "Rp 200.000", callback_data: "nominal_200000" },
    ],
    [
      { text: "Rp 500.000", callback_data: "nominal_500000" },
      { text: "Rp 1.000.000", callback_data: "nominal_1000000" },
    ],
    [{ text: "✏️  Nominal Lain...", callback_data: "nominal_custom" }],
    [{ text: "❌ Batalkan & Kembali ke Menu", callback_data: "menu_main" }],
  ],
};

export function qrisActiveKeyboard(sessionId: number): InlineKeyboardMarkup {
  return {
    inline_keyboard: [
      [{ text: "✅  Sudah Bayar", callback_data: `qris_paid_${sessionId}` }],
      [{ text: "🔄  Konversi QRIS Lain", callback_data: "menu_qris" }],
      [{ text: "🏠  Menu Utama", callback_data: "menu_main" }],
    ],
  };
}

export function qrisPaidKeyboard(): InlineKeyboardMarkup {
  return {
    inline_keyboard: [
      [{ text: "🔄  Konversi QRIS Lain", callback_data: "menu_qris" }],
      [{ text: "🏠  Menu Utama", callback_data: "menu_main" }],
    ],
  };
}

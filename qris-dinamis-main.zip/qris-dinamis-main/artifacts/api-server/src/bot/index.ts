import TelegramBot from "node-telegram-bot-api";
import { registerHandlers } from "./handlers.js";
import { logger } from "../lib/logger.js";

let botInstance: TelegramBot | null = null;

export function initBot(): TelegramBot | null {
  const token = process.env["TELEGRAM_BOT_TOKEN"];
  if (!token) {
    logger.warn("TELEGRAM_BOT_TOKEN tidak tersedia, bot tidak dijalankan.");
    return null;
  }

  if (botInstance) return botInstance;

  const bot = new TelegramBot(token, { polling: true });
  botInstance = bot;

  bot.on("polling_error", (err) => {
    logger.error({ err }, "Telegram polling error");
  });

  bot.on("error", (err) => {
    logger.error({ err }, "Telegram bot error");
  });

  registerHandlers(bot);

  logger.info("Telegram bot started (polling mode)");
  return bot;
}

export function getBot(): TelegramBot | null {
  return botInstance;
}

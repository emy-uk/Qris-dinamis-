import TelegramBot from "node-telegram-bot-api";

export async function sendChannelReport(
  bot: TelegramBot,
  channelId: string,
  params: {
    telegramId: number;
    username?: string;
    firstName?: string;
    feature: string;
    detail?: string;
    status: "✅ Berhasil" | "❌ Gagal";
    extra?: string;
  }
): Promise<void> {
  const name = params.firstName
    ? `${params.firstName}${params.username ? ` (@${params.username})` : ""}`
    : params.username
    ? `@${params.username}`
    : `User #${params.telegramId}`;

  const now = new Date().toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });

  let message = `📋 *LAPORAN AKTIVITAS BOT*\n`;
  message += `━━━━━━━━━━━━━━━━\n`;
  message += `👤 *Pengguna:* ${name}\n`;
  message += `🆔 *ID:* \`${params.telegramId}\`\n`;
  message += `🔧 *Fitur:* ${params.feature}\n`;
  message += `📌 *Status:* ${params.status}\n`;
  if (params.detail) message += `📝 *Detail:* ${params.detail}\n`;
  if (params.extra) message += `ℹ️ *Info:* ${params.extra}\n`;
  message += `🕐 *Waktu:* ${now} WIB`;

  try {
    await bot.sendMessage(channelId, message, { parse_mode: "Markdown" });
  } catch {
    // Non-critical: channel report failure should not block main flow
  }
}

import TelegramBot from "node-telegram-bot-api";
import type { Message, CallbackQuery, User, InlineKeyboardMarkup } from "node-telegram-bot-api";
import { ocrFromUrl } from "./ocr.js";
import { decodeQrisFromBuffer, parseQrisString, generateDynamicQris, generateQrImageUrl } from "./qris.js";
import {
  upsertUser, logUsage, saveQrisHistory, getUserHistory,
  createQrisSession, attachQrisSessionMessages, getQrisSession, updateQrisSessionStatus,
} from "./database.js";
import { sendChannelReport } from "./reporter.js";
import {
  mainMenuKeyboard,
  backToMenuKeyboard,
  cancelKeyboard,
  qrisNominalKeyboard,
  ocrLanguageKeyboard,
  qrisActiveKeyboard,
  qrisPaidKeyboard,
} from "./keyboards.js";
import axios from "axios";

const CHANNEL_ID = process.env["TELEGRAM_CHANNEL_ID"] ?? "";
const QRIS_EXPIRY_MS = 5 * 60 * 1000; // 5 menit

// ─── Session state ─────────────────────────────────────────────────────────
type SessionState =
  | { type: "idle" }
  | { type: "waiting_ocr"; lang: string }
  | { type: "waiting_qris_image" }
  | { type: "waiting_qris_nominal"; qrisString: string; merchantName: string }
  | { type: "waiting_custom_nominal"; qrisString: string; merchantName: string };

const sessions = new Map<number, SessionState>();
const qrisTimers = new Map<number, ReturnType<typeof setTimeout>>();

function getSession(userId: number): SessionState {
  return sessions.get(userId) ?? { type: "idle" };
}
function setSession(userId: number, state: SessionState): void {
  sessions.set(userId, state);
}

function formatRupiah(amount: number): string {
  return new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", minimumFractionDigits: 0 }).format(amount);
}

function formatCountdown(ms: number): string {
  const min = Math.floor(ms / 60000);
  const sec = Math.floor((ms % 60000) / 1000);
  return `${min}:${sec.toString().padStart(2, "0")}`;
}

// ─── QRIS expiry timer ──────────────────────────────────────────────────────
function scheduleQrisExpiry(
  bot: TelegramBot,
  sessionId: number,
  chatId: number,
  photoMessageId: number,
): void {
  const timer = setTimeout(async () => {
    qrisTimers.delete(sessionId);
    const session = getQrisSession(sessionId);
    if (!session || session.status !== "active") return;

    updateQrisSessionStatus(sessionId, "expired");

    try {
      await bot.editMessageCaption(
        "⏰ *QRIS Hangus!*\n\n" +
        `🏪 *Merchant:* ${session.merchant_name ?? "-"}\n` +
        `💰 *Nominal:* ${formatRupiah(session.nominal)}\n\n` +
        "_QRIS ini telah hangus karena sudah melebihi batas waktu 5 menit._",
        {
          chat_id: chatId,
          message_id: photoMessageId,
          parse_mode: "Markdown",
          reply_markup: qrisPaidKeyboard(),
        },
      );
    } catch {
      // Message may have been deleted — send new notification
      await bot.sendMessage(
        chatId,
        `⏰ *QRIS Hangus!*\n\n🏪 *Merchant:* ${session.merchant_name ?? "-"}\n💰 *Nominal:* ${formatRupiah(session.nominal)}\n\n_QRIS telah hangus setelah 5 menit. Silakan buat QRIS baru._`,
        { parse_mode: "Markdown", reply_markup: mainMenuKeyboard },
      );
    }
  }, QRIS_EXPIRY_MS);

  qrisTimers.set(sessionId, timer);
}

function cancelQrisTimer(sessionId: number): void {
  const t = qrisTimers.get(sessionId);
  if (t) {
    clearTimeout(t);
    qrisTimers.delete(sessionId);
  }
}

// ─── Handler registrations ──────────────────────────────────────────────────
export function registerHandlers(bot: TelegramBot): void {

  // /start
  bot.onText(/\/start/, async (msg) => {
    const { id, username, first_name, last_name } = msg.from!;
    upsertUser(id, username, first_name, last_name);
    setSession(id, { type: "idle" });
    const name = first_name ?? username ?? "Pengguna";
    await bot.sendMessage(
      msg.chat.id,
      `👋 *Halo, ${name}!*\n\nSelamat datang di *Bot Multi-Fitur* 🤖\n\n` +
      `Pilih fitur di bawah untuk mulai:`,
      { parse_mode: "Markdown", reply_markup: mainMenuKeyboard },
    );
  });

  // /menu
  bot.onText(/\/menu/, async (msg) => {
    const { id, username, first_name, last_name } = msg.from!;
    upsertUser(id, username, first_name, last_name);
    setSession(id, { type: "idle" });
    await bot.sendMessage(msg.chat.id, "🏠 *Menu Utama*\n\nPilih fitur:", {
      parse_mode: "Markdown",
      reply_markup: mainMenuKeyboard,
    });
  });

  // /help
  bot.onText(/\/help/, async (msg) => {
    await bot.sendMessage(msg.chat.id, getHelpText(), {
      parse_mode: "Markdown",
      reply_markup: backToMenuKeyboard,
    });
  });

  // Photo handler
  bot.on("photo", async (msg) => {
    const userId = msg.from!.id;
    const session = getSession(userId);
    if (session.type === "waiting_ocr") {
      await handleOcrPhoto(bot, msg, session.lang);
    } else if (session.type === "waiting_qris_image") {
      await handleQrisPhoto(bot, msg);
    } else {
      await bot.sendMessage(
        msg.chat.id,
        "📸 *Gambar diterima!*\n\nApa yang ingin kamu lakukan dengan gambar ini?",
        {
          parse_mode: "Markdown",
          reply_markup: {
            inline_keyboard: [
              [{ text: "📷  Ekstrak Teks (OCR)", callback_data: "quick_ocr" }],
              [{ text: "🔄  Baca sebagai QRIS", callback_data: "quick_qris" }],
              [{ text: "❌ Batalkan & Kembali ke Menu", callback_data: "menu_main" }],
            ],
          } as InlineKeyboardMarkup,
        },
      );
    }
  });

  // Text message handler (custom nominal input)
  bot.on("message", async (msg) => {
    if (msg.photo || !msg.text || msg.text.startsWith("/")) return;
    const userId = msg.from!.id;
    const session = getSession(userId);
    if (session.type !== "waiting_custom_nominal") return;

    const nominalStr = msg.text.replace(/[^0-9]/g, "");
    const nominal = parseInt(nominalStr, 10);

    if (isNaN(nominal) || nominal < 100) {
      await bot.sendMessage(
        msg.chat.id,
        "❌ Nominal tidak valid. Masukkan angka minimal Rp 100.\n\nContoh: `15000` atau `75000`",
        { parse_mode: "Markdown", reply_markup: cancelKeyboard },
      );
      return;
    }
    if (nominal > 100_000_000) {
      await bot.sendMessage(msg.chat.id, "❌ Nominal terlalu besar. Maksimum Rp 100.000.000.", {
        reply_markup: cancelKeyboard,
      });
      return;
    }

    await processQrisWithNominal(bot, msg.chat.id, userId, session.qrisString, session.merchantName, nominal, msg.from!);
  });

  // Callback query handler
  bot.on("callback_query", async (query: CallbackQuery) => {
    const msg = query.message!;
    const userId = query.from.id;
    const chatId = msg.chat.id;
    const msgId = msg.message_id;
    const data = query.data ?? "";

    await bot.answerCallbackQuery(query.id);

    // ── Navigation ──────────────────────────────────────────────────────────
    if (data === "menu_main") {
      setSession(userId, { type: "idle" });
      try {
        await bot.editMessageText("🏠 *Menu Utama*\n\nPilih fitur:", {
          chat_id: chatId, message_id: msgId,
          parse_mode: "Markdown", reply_markup: mainMenuKeyboard,
        });
      } catch {
        await bot.sendMessage(chatId, "🏠 *Menu Utama*\n\nPilih fitur:", {
          parse_mode: "Markdown", reply_markup: mainMenuKeyboard,
        });
      }
      return;
    }

    // ── OCR menu ────────────────────────────────────────────────────────────
    if (data === "menu_ocr") {
      await bot.editMessageText(
        "📷 *OCR — Foto ke Teks*\n\nPilih bahasa untuk pengenalan teks:",
        { chat_id: chatId, message_id: msgId, parse_mode: "Markdown", reply_markup: ocrLanguageKeyboard },
      );
      return;
    }

    if (data.startsWith("ocr_lang_")) {
      const lang = data.replace("ocr_lang_", "");
      setSession(userId, { type: "waiting_ocr", lang });
      const langLabel = lang === "ind+eng" ? "🇮🇩 Indonesia + Inggris" : "🇬🇧 Inggris";
      await bot.editMessageText(
        `📷 *OCR Siap!*\n\nBahasa: ${langLabel}\n\n📤 Kirimkan foto yang ingin diekstrak teksnya:`,
        { chat_id: chatId, message_id: msgId, parse_mode: "Markdown", reply_markup: cancelKeyboard },
      );
      return;
    }

    if (data === "quick_ocr") {
      setSession(userId, { type: "waiting_ocr", lang: "ind+eng" });
      await bot.editMessageText(
        "📷 *Mode OCR Aktif*\n\n📤 Kirimkan foto yang ingin diekstrak teksnya:",
        { chat_id: chatId, message_id: msgId, parse_mode: "Markdown", reply_markup: cancelKeyboard },
      );
      return;
    }

    // ── QRIS menu ────────────────────────────────────────────────────────────
    if (data === "menu_qris" || data === "quick_qris") {
      setSession(userId, { type: "waiting_qris_image" });
      try {
        await bot.editMessageText(
          "🔄 *QRIS Statis → Dinamis*\n\n📤 Kirimkan foto QRIS statis yang ingin dikonversi:\n\n_Pastikan gambar jelas, tidak buram, dan QR code tidak terpotong._",
          { chat_id: chatId, message_id: msgId, parse_mode: "Markdown", reply_markup: cancelKeyboard },
        );
      } catch {
        await bot.sendMessage(
          chatId,
          "🔄 *QRIS Statis → Dinamis*\n\n📤 Kirimkan foto QRIS statis yang ingin dikonversi:",
          { parse_mode: "Markdown", reply_markup: cancelKeyboard },
        );
      }
      return;
    }

    // ── History ──────────────────────────────────────────────────────────────
    if (data === "menu_history") {
      await showUserHistory(bot, chatId, msgId, userId);
      return;
    }

    // ── Help ─────────────────────────────────────────────────────────────────
    if (data === "menu_help") {
      await bot.editMessageText(getHelpText(), {
        chat_id: chatId, message_id: msgId,
        parse_mode: "Markdown", reply_markup: backToMenuKeyboard,
      });
      return;
    }

    // ── QRIS nominal selection ───────────────────────────────────────────────
    if (data.startsWith("nominal_")) {
      const session = getSession(userId);
      if (session.type !== "waiting_qris_nominal") return;

      if (data === "nominal_custom") {
        setSession(userId, {
          type: "waiting_custom_nominal",
          qrisString: session.qrisString,
          merchantName: session.merchantName,
        });
        await bot.sendMessage(
          chatId,
          "✏️ *Masukkan nominal pembayaran:*\n\nContoh: `15000` atau `75000`",
          { parse_mode: "Markdown", reply_markup: cancelKeyboard },
        );
        return;
      }

      const nominal = parseInt(data.replace("nominal_", ""), 10);
      await processQrisWithNominal(bot, chatId, userId, session.qrisString, session.merchantName, nominal, query.from);
      return;
    }

    // ── QRIS Sudah Bayar ─────────────────────────────────────────────────────
    if (data.startsWith("qris_paid_")) {
      const sessionId = parseInt(data.replace("qris_paid_", ""), 10);
      const qrisSession = getQrisSession(sessionId);

      if (!qrisSession) {
        await bot.answerCallbackQuery(query.id, { text: "Sesi QRIS tidak ditemukan." });
        return;
      }

      if (qrisSession.status === "expired") {
        await bot.answerCallbackQuery(query.id, {
          text: "⏰ QRIS ini sudah hangus!",
          show_alert: true,
        });
        return;
      }

      if (qrisSession.status === "paid") {
        await bot.answerCallbackQuery(query.id, {
          text: "✅ Pembayaran sudah dikonfirmasi sebelumnya.",
          show_alert: true,
        });
        return;
      }

      // Mark as paid and cancel the expiry timer
      cancelQrisTimer(sessionId);
      updateQrisSessionStatus(sessionId, "paid");

      try {
        await bot.editMessageCaption(
          `✅ *Pembayaran Dikonfirmasi!*\n\n` +
          `🏪 *Merchant:* ${qrisSession.merchant_name ?? "-"}\n` +
          `💰 *Nominal:* ${formatRupiah(qrisSession.nominal)}\n\n` +
          `_Terima kasih! QRIS ini sudah tidak aktif._`,
          {
            chat_id: chatId,
            message_id: msgId,
            parse_mode: "Markdown",
            reply_markup: qrisPaidKeyboard(),
          },
        );
      } catch {
        await bot.sendMessage(
          chatId,
          `✅ *Pembayaran Dikonfirmasi!*\n\n🏪 *Merchant:* ${qrisSession.merchant_name ?? "-"}\n💰 *Nominal:* ${formatRupiah(qrisSession.nominal)}`,
          { parse_mode: "Markdown", reply_markup: mainMenuKeyboard },
        );
      }

      logUsage(userId, "QRIS_PAID", `${qrisSession.merchant_name} - ${formatRupiah(qrisSession.nominal)}`);
      return;
    }
  });
}

// ─── OCR handler ─────────────────────────────────────────────────────────────
async function handleOcrPhoto(bot: TelegramBot, msg: Message, lang: string): Promise<void> {
  const userId = msg.from!.id;
  const chatId = msg.chat.id;
  setSession(userId, { type: "idle" });

  const processingMsg = await bot.sendMessage(chatId, "⏳ Sedang memproses OCR... Mohon tunggu.");

  try {
    const photo = msg.photo![msg.photo!.length - 1];
    const fileInfo = await bot.getFile(photo.file_id);
    const fileUrl = `https://api.telegram.org/file/bot${process.env["TELEGRAM_BOT_TOKEN"]}/${fileInfo.file_path}`;

    const text = await ocrFromUrl(fileUrl);
    await bot.deleteMessage(chatId, processingMsg.message_id);

    const truncated = text.length > 3800 ? text.substring(0, 3800) + "\n\n_...[teks terpotong]_" : text;

    await bot.sendMessage(
      chatId,
      `📝 *Hasil OCR:*\n\`\`\`\n${truncated}\n\`\`\``,
      { parse_mode: "Markdown", reply_markup: mainMenuKeyboard },
    );

    logUsage(userId, "OCR", `${text.length} karakter`);
    await sendChannelReport(bot, CHANNEL_ID, {
      telegramId: userId, username: msg.from!.username, firstName: msg.from!.first_name,
      feature: "📷 OCR Foto → Teks",
      detail: `${text.length} karakter diekstrak`,
      status: "✅ Berhasil",
    });
  } catch (err) {
    await bot.deleteMessage(chatId, processingMsg.message_id);
    const errorMsg = err instanceof Error ? err.message : "Terjadi kesalahan";
    await bot.sendMessage(chatId, `❌ OCR gagal: ${errorMsg}`, { reply_markup: mainMenuKeyboard });
    logUsage(userId, "OCR", `Gagal: ${errorMsg}`);
    await sendChannelReport(bot, CHANNEL_ID, {
      telegramId: userId, username: msg.from!.username, firstName: msg.from!.first_name,
      feature: "📷 OCR Foto → Teks", status: "❌ Gagal", detail: errorMsg,
    });
  }
}

// ─── QRIS photo handler ───────────────────────────────────────────────────────
async function handleQrisPhoto(bot: TelegramBot, msg: Message): Promise<void> {
  const userId = msg.from!.id;
  const chatId = msg.chat.id;
  setSession(userId, { type: "idle" });

  const processingMsg = await bot.sendMessage(chatId, "⏳ Sedang membaca QRIS... Mohon tunggu.");

  try {
    const photo = msg.photo![msg.photo!.length - 1];
    const fileInfo = await bot.getFile(photo.file_id);
    const fileUrl = `https://api.telegram.org/file/bot${process.env["TELEGRAM_BOT_TOKEN"]}/${fileInfo.file_path}`;

    const imgRes = await axios.get(fileUrl, { responseType: "arraybuffer", timeout: 15000 });
    const buffer = Buffer.from(imgRes.data as ArrayBuffer);

    const qrisString = await decodeQrisFromBuffer(buffer);
    const qrisData = parseQrisString(qrisString);

    await bot.deleteMessage(chatId, processingMsg.message_id);

    if (!qrisData.isValid) {
      await bot.sendMessage(chatId, `❌ QRIS tidak valid:\n${qrisData.errorMessage}`, { reply_markup: mainMenuKeyboard });
      return;
    }

    setSession(userId, { type: "waiting_qris_nominal", qrisString, merchantName: qrisData.merchantName });

    await bot.sendMessage(
      chatId,
      `✅ *QRIS Berhasil Dibaca!*\n\n` +
      `🏪 *Merchant:* ${qrisData.merchantName}\n` +
      `🏙️ *Kota:* ${qrisData.merchantCity || "-"}\n` +
      `🌏 *Negara:* ${qrisData.countryCode}\n\n` +
      `💵 *Pilih nominal pembayaran:*`,
      { parse_mode: "Markdown", reply_markup: qrisNominalKeyboard },
    );
  } catch (err) {
    await bot.deleteMessage(chatId, processingMsg.message_id);
    const errorMsg = err instanceof Error ? err.message : "Terjadi kesalahan";
    await bot.sendMessage(
      chatId,
      `❌ *Gagal membaca QRIS*\n\n${errorMsg}\n\n_Pastikan gambar QRIS jelas dan tidak terpotong._`,
      { parse_mode: "Markdown", reply_markup: mainMenuKeyboard },
    );
    logUsage(userId, "QRIS", `Gagal baca: ${errorMsg}`);
    await sendChannelReport(bot, CHANNEL_ID, {
      telegramId: userId, username: msg.from!.username, firstName: msg.from!.first_name,
      feature: "🔄 QRIS Statis → Dinamis", status: "❌ Gagal", detail: errorMsg,
    });
  }
}

// ─── Process QRIS with chosen nominal ────────────────────────────────────────
async function processQrisWithNominal(
  bot: TelegramBot,
  chatId: number,
  userId: number,
  qrisString: string,
  merchantName: string,
  nominal: number,
  from: User,
): Promise<void> {
  setSession(userId, { type: "idle" });
  const processingMsg = await bot.sendMessage(chatId, `⏳ Membuat QRIS dinamis ${formatRupiah(nominal)}...`);

  try {
    const dynamicQris = generateDynamicQris(qrisString, nominal);
    const qrImageUrl = generateQrImageUrl(dynamicQris, 400);

    const imgRes = await axios.get(qrImageUrl, { responseType: "arraybuffer", timeout: 15000 });
    const imgBuffer = Buffer.from(imgRes.data as ArrayBuffer);

    await bot.deleteMessage(chatId, processingMsg.message_id);

    // Create DB session FIRST to get the ID for the button
    const sessionId = createQrisSession({
      telegramId: userId,
      chatId,
      merchantName,
      originalQris: qrisString,
      dynamicQris,
      nominal,
    });

    const expiryText = formatCountdown(QRIS_EXPIRY_MS);

    // Send QR code image with Sudah Bayar button
    const photoMsg = await bot.sendPhoto(chatId, imgBuffer, {
      caption:
        `🔄 *QRIS Dinamis Berhasil Dibuat!*\n\n` +
        `🏪 *Merchant:* ${merchantName}\n` +
        `💰 *Nominal:* ${formatRupiah(nominal)}\n` +
        `⏰ *Hangus dalam:* ${expiryText} menit\n\n` +
        `_Scan QR code di atas untuk membayar._\n` +
        `_Tekan ✅ Sudah Bayar setelah transaksi selesai._`,
      parse_mode: "Markdown",
      reply_markup: qrisActiveKeyboard(sessionId),
    });

    // Also send the raw QRIS string
    const stringMsg = await bot.sendMessage(
      chatId,
      `📋 *String QRIS Dinamis:*\n\`\`\`\n${dynamicQris}\n\`\`\``,
      { parse_mode: "Markdown" },
    );

    // Attach message IDs to session for editing later
    attachQrisSessionMessages(sessionId, photoMsg.message_id, stringMsg.message_id);

    // Schedule auto-expiry after 5 minutes
    scheduleQrisExpiry(bot, sessionId, chatId, photoMsg.message_id);

    logUsage(userId, "QRIS", `${merchantName} - ${formatRupiah(nominal)}`);
    saveQrisHistory(userId, merchantName, qrisString, nominal);

    await sendChannelReport(bot, CHANNEL_ID, {
      telegramId: userId, username: from.username, firstName: from.first_name,
      feature: "🔄 QRIS Statis → Dinamis",
      detail: `${merchantName} - ${formatRupiah(nominal)}`,
      status: "✅ Berhasil",
    });
  } catch (err) {
    await bot.deleteMessage(chatId, processingMsg.message_id);
    const errorMsg = err instanceof Error ? err.message : "Terjadi kesalahan";
    await bot.sendMessage(chatId, `❌ Gagal membuat QRIS dinamis: ${errorMsg}`, { reply_markup: mainMenuKeyboard });
    logUsage(userId, "QRIS", `Gagal generate: ${errorMsg}`);
  }
}

// ─── Show history ─────────────────────────────────────────────────────────────
async function showUserHistory(bot: TelegramBot, chatId: number, messageId: number, userId: number): Promise<void> {
  const history = getUserHistory(userId, 10);

  if (history.length === 0) {
    await bot.editMessageText("📜 *Riwayat Saya*\n\nBelum ada riwayat penggunaan.", {
      chat_id: chatId, message_id: messageId,
      parse_mode: "Markdown", reply_markup: backToMenuKeyboard,
    });
    return;
  }

  let text = "📜 *Riwayat Penggunaan (10 terakhir):*\n\n";
  for (const item of history) {
    const date = new Date(item.created_at).toLocaleString("id-ID", {
      timeZone: "Asia/Jakarta", day: "2-digit", month: "2-digit",
      year: "2-digit", hour: "2-digit", minute: "2-digit",
    });
    const icon = item.feature === "OCR" ? "📷" : item.feature === "QRIS_PAID" ? "✅" : "🔄";
    text += `${icon} *${item.feature}*\n  ${item.detail ?? "-"}\n  _${date}_\n\n`;
  }

  await bot.editMessageText(text, {
    chat_id: chatId, message_id: messageId,
    parse_mode: "Markdown", reply_markup: backToMenuKeyboard,
  });
}

// ─── Help text ────────────────────────────────────────────────────────────────
function getHelpText(): string {
  return (
    `ℹ️ *Bantuan Bot Multi-Fitur*\n\n` +
    `*📷 OCR (Foto → Teks)*\n` +
    `Ubah foto berisi teks menjadi teks digital.\n` +
    `Mendukung bahasa Indonesia & Inggris.\n\n` +
    `*🔄 QRIS Statis → Dinamis*\n` +
    `Konversi QRIS statis menjadi QRIS dinamis dengan nominal tertentu.\n` +
    `• QRIS hangus otomatis setelah *5 menit*\n` +
    `• Tekan ✅ *Sudah Bayar* setelah transaksi selesai\n` +
    `• Menggunakan API goqr.me (EMV QRCPS)\n\n` +
    `*📋 Perintah:*\n` +
    `/start — Menu utama\n` +
    `/menu — Menu utama\n` +
    `/help — Bantuan\n\n` +
    `*💡 Tips:*\n` +
    `• Foto QRIS harus jelas & tidak buram\n` +
    `• Pencahayaan cukup untuk hasil OCR terbaik\n` +
    `• Satu QRIS dinamis hanya untuk satu transaksi`
  );
}

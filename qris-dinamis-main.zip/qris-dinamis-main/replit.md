# Bot Telegram Multi-Fitur

Bot Telegram yang dapat mengubah foto menjadi teks (OCR) dan mengkonversi QRIS statis menjadi QRIS dinamis dengan nominal tertentu.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — jalankan API server + Telegram bot (port 8080)
- `pnpm run typecheck` — full typecheck semua package
- `pnpm run build` — typecheck + build semua package
- Data SQLite tersimpan di `data/bot.db` (dibuat otomatis)

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- Bot: node-telegram-bot-api (polling mode)
- OCR: Tesseract.js (bahasa Indonesia + Inggris)
- QRIS: API goqr.me untuk baca/buat QR code, EMV QRCPS parser buatan sendiri
- DB: SQLite via better-sqlite3
- Build: esbuild (ESM bundle)

## Where things live

- `artifacts/api-server/src/bot/` — semua kode bot Telegram
  - `index.ts` — inisialisasi bot
  - `handlers.ts` — semua handler pesan & callback
  - `keyboards.ts` — definisi inline keyboard
  - `database.ts` — SQLite schema & query helpers
  - `ocr.ts` — Tesseract.js OCR wrapper
  - `qris.ts` — QRIS decoder/generator (goqr.me + EMV parser)
  - `reporter.ts` — laporan ke channel Telegram
- `data/bot.db` — database SQLite (dibuat otomatis)

## Architecture decisions

- Bot berjalan dalam proses Express yang sama (polling mode, bukan webhook) agar mudah dijalankan tanpa setup domain SSL.
- Database SQLite dipilih karena ringan dan tidak memerlukan server terpisah.
- QRIS diproses dengan dua langkah: decode gambar via goqr.me API, lalu parse/generate string EMV QRCPS secara lokal dengan CRC16-CCITT.
- Session state disimpan in-memory (Map) per user ID — cukup untuk satu instance bot.
- Setiap penggunaan fitur langsung mengirim laporan ke channel Telegram yang dikonfigurasi.

## Product

- `/start` atau `/menu` — tampilkan menu utama dengan tombol inline
- **OCR** — kirim foto, bot ekstrak semua teks (mendukung Indonesia + Inggris)
- **QRIS Statis → Dinamis** — kirim foto QRIS, pilih nominal, bot hasilkan QRIS dinamis baru sebagai gambar + string
- **Riwayat** — lihat 10 penggunaan terakhir
- **Laporan channel** — setiap aksi user dikirim otomatis ke channel Telegram

## User preferences

- Gunakan SQLite (bukan MySQL/PostgreSQL) karena lebih simpel untuk bot
- Menu full button (inline keyboard)
- Gunakan API goqr.me untuk decode dan generate QR code

## Gotchas

- `better-sqlite3` butuh `onlyBuiltDependencies` di `pnpm-workspace.yaml` agar native module ter-build
- Database path menggunakan `process.cwd()` bukan `__dirname` karena setelah di-bundle path berubah
- Bot berjalan di polling mode — jangan jalankan dua instance sekaligus (akan conflict)
- CHANNEL_ID harus berupa `@namaChannel` (publik) atau ID numerik `-100xxxxxxxxxx` (privat)

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details

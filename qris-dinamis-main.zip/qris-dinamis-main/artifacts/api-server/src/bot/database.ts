import Database from "better-sqlite3";
import path from "path";
import fs from "fs";

const DATA_DIR = path.resolve(process.cwd(), "data");
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
const DB_PATH = path.join(DATA_DIR, "bot.db");

const db = new Database(DB_PATH);

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    telegram_id INTEGER UNIQUE NOT NULL,
    username TEXT,
    first_name TEXT,
    last_name TEXT,
    created_at TEXT DEFAULT (datetime('now')),
    last_active TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS usage_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_id INTEGER NOT NULL,
    feature TEXT NOT NULL,
    detail TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS qris_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_id INTEGER NOT NULL,
    merchant_name TEXT,
    original_qris TEXT,
    nominal INTEGER,
    created_at TEXT DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS qris_sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_id INTEGER NOT NULL,
    chat_id INTEGER NOT NULL,
    photo_message_id INTEGER,
    string_message_id INTEGER,
    merchant_name TEXT,
    original_qris TEXT,
    dynamic_qris TEXT,
    nominal INTEGER,
    status TEXT DEFAULT 'active',
    expires_at TEXT,
    created_at TEXT DEFAULT (datetime('now'))
  );
`);

export interface User {
  id: number;
  telegram_id: number;
  username: string | null;
  first_name: string | null;
  last_name: string | null;
  created_at: string;
  last_active: string;
}

export interface QrisSession {
  id: number;
  telegram_id: number;
  chat_id: number;
  photo_message_id: number | null;
  string_message_id: number | null;
  merchant_name: string | null;
  original_qris: string | null;
  dynamic_qris: string | null;
  nominal: number;
  status: "active" | "paid" | "expired";
  expires_at: string;
  created_at: string;
}

export function upsertUser(telegramId: number, username?: string, firstName?: string, lastName?: string): User {
  const stmt = db.prepare(`
    INSERT INTO users (telegram_id, username, first_name, last_name)
    VALUES (?, ?, ?, ?)
    ON CONFLICT(telegram_id) DO UPDATE SET
      username = excluded.username,
      first_name = excluded.first_name,
      last_name = excluded.last_name,
      last_active = datetime('now')
    RETURNING *
  `);
  return stmt.get(telegramId, username ?? null, firstName ?? null, lastName ?? null) as User;
}

export function logUsage(telegramId: number, feature: string, detail?: string): void {
  db.prepare(`INSERT INTO usage_logs (telegram_id, feature, detail) VALUES (?, ?, ?)`)
    .run(telegramId, feature, detail ?? null);
}

export function saveQrisHistory(telegramId: number, merchantName: string, originalQris: string, nominal: number): void {
  db.prepare(`INSERT INTO qris_history (telegram_id, merchant_name, original_qris, nominal) VALUES (?, ?, ?, ?)`)
    .run(telegramId, merchantName, originalQris, nominal);
}

/** Create a QRIS session with 5-minute expiry and return its ID */
export function createQrisSession(params: {
  telegramId: number;
  chatId: number;
  merchantName: string;
  originalQris: string;
  dynamicQris: string;
  nominal: number;
}): number {
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000).toISOString();
  const result = db.prepare(`
    INSERT INTO qris_sessions (telegram_id, chat_id, merchant_name, original_qris, dynamic_qris, nominal, expires_at)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `).run(params.telegramId, params.chatId, params.merchantName, params.originalQris, params.dynamicQris, params.nominal, expiresAt);
  return result.lastInsertRowid as number;
}

/** Attach message IDs to a QRIS session after sending */
export function attachQrisSessionMessages(sessionId: number, photoMessageId: number, stringMessageId: number): void {
  db.prepare(`UPDATE qris_sessions SET photo_message_id = ?, string_message_id = ? WHERE id = ?`)
    .run(photoMessageId, stringMessageId, sessionId);
}

export function getQrisSession(sessionId: number): QrisSession | undefined {
  return db.prepare(`SELECT * FROM qris_sessions WHERE id = ?`).get(sessionId) as QrisSession | undefined;
}

export function updateQrisSessionStatus(sessionId: number, status: "paid" | "expired"): void {
  db.prepare(`UPDATE qris_sessions SET status = ? WHERE id = ?`).run(status, sessionId);
}

export function getUserStats(): { total_users: number; total_ocr: number; total_qris: number } {
  const users = (db.prepare(`SELECT COUNT(*) as count FROM users`).get() as { count: number }).count;
  const ocr = (db.prepare(`SELECT COUNT(*) as count FROM usage_logs WHERE feature = 'OCR'`).get() as { count: number }).count;
  const qris = (db.prepare(`SELECT COUNT(*) as count FROM usage_logs WHERE feature = 'QRIS'`).get() as { count: number }).count;
  return { total_users: users, total_ocr: ocr, total_qris: qris };
}

export function getUserHistory(telegramId: number, limit = 10): Array<{ feature: string; detail: string | null; created_at: string }> {
  return db.prepare(`SELECT feature, detail, created_at FROM usage_logs WHERE telegram_id = ? ORDER BY created_at DESC LIMIT ?`)
    .all(telegramId, limit) as Array<{ feature: string; detail: string | null; created_at: string }>;
}

export default db;

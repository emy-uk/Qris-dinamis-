---
name: Tesseract.js esbuild externalize
description: tesseract.js must be in the external[] list in build.mjs or the worker thread crashes on startup
---

# Tesseract.js Must Be Externalized in esbuild

**Rule:** Always add `"tesseract.js"` to the `external` array in `artifacts/api-server/build.mjs`.

**Why:** Tesseract.js spawns worker threads that resolve their own files at runtime via node_modules path traversal. When bundled by esbuild, the worker script path (`worker-script/node/index.js`) gets broken and Node.js throws `MODULE_NOT_FOUND` on startup.

**How to apply:** Any time tesseract.js is used in the api-server artifact, ensure it appears in the esbuild `external[]` list alongside `better-sqlite3`.
